#include <ntddk.h>
#include <ntddmou.h>

// Định nghĩa IOCTL
#define IOCTL_MOVE_MOUSE CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, METHOD_BUFFERED, FILE_ANY_ACCESS)

// Cấu trúc di chuyển chuột
typedef struct _MOUSE_MOVE {
    LONG dx;
    LONG dy;
} MOUSE_MOVE, *PMOUSE_MOVE;

// Biến toàn cục cho MouseClass
PDEVICE_OBJECT g_MouseDevice = NULL;
PFILE_OBJECT g_MouseFile = NULL;

// Kết nối với MouseClass
NTSTATUS ConnectToMouseClass() {
    UNICODE_STRING mouseClassName = RTL_CONSTANT_STRING(L"\\Device\\PointerClass0");
    NTSTATUS status = IoGetDeviceObjectPointer(&mouseClassName, FILE_ALL_ACCESS, &g_MouseFile, &g_MouseDevice);
    if (!NT_SUCCESS(status)) {
        DbgPrint("Failed to connect to MouseClass: 0x%x\n", status);
    }
    return status;
}

// Ngắt kết nối MouseClass
VOID DisconnectFromMouseClass() {
    if (g_MouseFile) {
        ObDereferenceObject(g_MouseFile);
        g_MouseFile = NULL;
    }
    g_MouseDevice = NULL;
}

// Gửi sự kiện chuột
VOID SendMouseInput(LONG dx, LONG dy) {
    if (!g_MouseDevice) {
        DbgPrint("MouseClass not connected\n");
        return;
    }

    // Thêm trễ ngẫu nhiên để giả lập hành vi người dùng
    LARGE_INTEGER seed;
    KeQuerySystemTime(&seed);
    ULONG randomDelay = RtlRandomEx(&seed.LowPart) % 5;
    KeStallExecutionProcessor(randomDelay * 1000);

    // Tạo cấu trúc MOUSE_INPUT_DATA
    MOUSE_INPUT_DATA mouseData = { 0 };
    mouseData.LastX = dx;
    mouseData.LastY = dy;
    mouseData.Flags = MOUSE_MOVE_RELATIVE;

    // Tạo IRP để gửi dữ liệu
    IO_STATUS_BLOCK ioStatus;
    PIRP irp = IoBuildDeviceIoControlRequest(
        IOCTL_INTERNAL_MOUSE_INPUT,
        g_MouseDevice,
        &mouseData,
        sizeof(MOUSE_INPUT_DATA),
        NULL,
        0,
        TRUE, // Internal
        NULL,
        &ioStatus
    );

    if (irp) {
        NTSTATUS status = IoCallDriver(g_MouseDevice, irp);
        if (!NT_SUCCESS(status)) {
            DbgPrint("Failed to send mouse input: 0x%x\n", status);
        }
    } else {
        DbgPrint("Failed to build IRP\n");
    }
}

// Tạo tên ngẫu nhiên
VOID GenerateRandomName(PUNICODE_STRING outName, BOOLEAN isDevice) {
    LARGE_INTEGER seed;
    KeQuerySystemTime(&seed);
    ULONG random = RtlRandomEx(&seed.LowPart);
    WCHAR buffer[32];
    swprintf(buffer, isDevice ? L"\\Device\\Input%08X" : L"\\DosDevices\\Input%08X", random);
    RtlInitUnicodeString(outName, buffer);
}

// Mã hóa/giải mã IOCTL
VOID EncryptMouseMove(PMOUSE_MOVE input, PMOUSE_MOVE output, ULONG key) {
    output->dx = input->dx ^ key;
    output->dy = input->dy ^ key;
}

VOID DecryptMouseMove(PMOUSE_MOVE input, PMOUSE_MOVE output, ULONG key) {
    output->dx = input->dx ^ key;
    output->dy = input->dy ^ key;
}

VOID UnloadDriver(PDRIVER_OBJECT DriverObject) {
    DisconnectFromMouseClass();
    UNICODE_STRING symlink;
    GenerateRandomName(&symlink, FALSE);
    IoDeleteSymbolicLink(&symlink);
    IoDeleteDevice(DriverObject->DeviceObject);
    DbgPrint("AimbotDriver unloaded\n");
}

NTSTATUS DeviceControl(PDEVICE_OBJECT DeviceObject, PIRP Irp) {
    PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
    NTSTATUS status = STATUS_SUCCESS;
    ULONG ioControlCode = stack->Parameters.DeviceIoControl.IoControlCode;

    if (ioControlCode == IOCTL_MOVE_MOUSE) {
        MOUSE_MOVE* input = (MOUSE_MOVE*)Irp->AssociatedIrp.SystemBuffer;
        if (input && stack->Parameters.DeviceIoControl.InputBufferLength >= sizeof(MOUSE_MOVE)) {
            MOUSE_MOVE decrypted;
            DecryptMouseMove(input, &decrypted, 0xDEADBEEF);
            SendMouseInput(decrypted.dx, decrypted.dy);
        } else {
            status = STATUS_INVALID_PARAMETER;
        }
    } else {
        status = STATUS_INVALID_DEVICE_REQUEST;
    }

    Irp->IoStatus.Status = status;
    Irp->IoStatus.Information = 0;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return status;
}

NTSTATUS CreateClose(PDEVICE_OBJECT DeviceObject, PIRP Irp) {
    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return STATUS_SUCCESS;
}

NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath) {
    UNICODE_STRING deviceName, symlink;
    PDEVICE_OBJECT deviceObject = NULL;
    NTSTATUS status;

    // Kết nối với MouseClass
    status = ConnectToMouseClass();
    if (!NT_SUCCESS(status)) {
        return status;
    }

    // Tạo tên thiết bị và symbolic link
    GenerateRandomName(&deviceName, TRUE);
    GenerateRandomName(&symlink, FALSE);

    status = IoCreateDevice(DriverObject, 0, &deviceName, FILE_DEVICE_UNKNOWN, 0, FALSE, &deviceObject);
    if (!NT_SUCCESS(status)) {
        DisconnectFromMouseClass();
        return status;
    }

    status = IoCreateSymbolicLink(&symlink, &deviceName);
    if (!NT_SUCCESS(status)) {
        IoDeleteDevice(deviceObject);
        DisconnectFromMouseClass();
        return status;
    }

    DriverObject->MajorFunction[IRP_MJ_CREATE] = CreateClose;
    DriverObject->MajorFunction[IRP_MJ_CLOSE] = CreateClose;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DeviceControl;
    DriverObject->DriverUnload = UnloadDriver;

    DbgPrint("AimbotDriver loaded\n");
    return STATUS_SUCCESS;
}