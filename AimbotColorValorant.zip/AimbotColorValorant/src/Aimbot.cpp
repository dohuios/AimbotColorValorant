#include <imgui.h>
#include <imgui_impl_dx11.h>
#include <imgui_impl_win32.h>
#include <opencv2/opencv.hpp>
#include <windows.h>
#include <winioctl.h>
#include <string>
#include <d3d11.h>
#include <thread>

// Định nghĩa IOCTL
#define IOCTL_MOVE_MOUSE CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, METHOD_BUFFERED, FILE_ANY_ACCESS)

// Cấu trúc di chuyển chuột
struct MOUSE_MOVE {
    LONG dx;
    LONG dy;
};

// Cấu trúc cài đặt
struct AimbotSettings {
    bool enabled = false;
    float fov = 50.0f;
    int smoothness = 5;
    int speed = 5;
    int delay = 5;
    int key = VK_LBUTTON;
    bool always_aim = false;
    int always_aim_key = VK_CAPITAL;
};

struct AssistSettings {
    bool enabled = false;
    float fov = 30.0f;
    int smoothness = 3;
    int speed = 3;
    int delay = 5;
    int key = VK_RBUTTON;
};

struct OffsetSettings {
    float head_offset_x = 0.0f;
    float head_offset_y = -5.0f;
};

struct TriggerbotSettings {
    bool enabled = false;
    float fov_x = 5.0f;
    float fov_y = 5.0f;
    int delay = 5;
    int sleep = 5;
    int key = VK_XBUTTON1;
};

AimbotSettings aimbot;
AssistSettings assist;
OffsetSettings offsets;
TriggerbotSettings triggerbot;

// Biến trạng thái chọn phím
bool selecting_aimbot_key = false;
bool selecting_always_aim_key = false;
bool selecting_triggerbot_key = false;
bool selecting_assist_key = false;

// DirectX 11 globals
static ID3D11Device* g_pd3dDevice = nullptr;
static ID3D11DeviceContext* g_pd3dDeviceContext = nullptr;
static IDXGISwapChain* g_pSwapChain = nullptr;
static ID3D11RenderTargetView* g_mainRenderTargetView = nullptr;

// Hàm chuyển mã VK sang tên phím
std::string GetKeyName(int vk_code) {
    if (vk_code == VK_LBUTTON) return "LButton";
    if (vk_code == VK_RBUTTON) return "RButton";
    if (vk_code == VK_MBUTTON) return "MButton";
    if (vk_code == VK_XBUTTON1) return "XButton1";
    if (vk_code == VK_XBUTTON2) return "XButton2";
    if (vk_code == VK_CONTROL) return "Ctrl";
    if (vk_code == VK_MENU) return "Alt";
    if (vk_code == VK_SHIFT) return "Shift";
    if (vk_code == VK_CAPITAL) return "CapsLock";
    if (vk_code >= 0x30 && vk_code <= 0x39) return std::string(1, char(vk_code));
    if (vk_code >= 0x41 && vk_code <= 0x5A) return std::string(1, char(vk_code));
    if (vk_code >= VK_F1 && vk_code <= VK_F12) return "F" + std::to_string(vk_code - VK_F1 + 1);
    return "Unknown";
}

// Hàm kiểm tra phím được nhấn
int GetPressedKey() {
    for (int i = 0x01; i <= 0xFE; ++i) {
        if (GetAsyncKeyState(i) & 0x8000) {
            return i;
        }
    }
    return -1;
}

// Phát hiện màu tím
bool IsPurplePixel(const cv::Vec3b& pixel) {
    cv::Mat rgb(1, 1, CV_8UC3, pixel);
    cv::Mat hsv;
    cv::cvtColor(rgb, hsv, cv::COLOR_RGB2HSV);
    auto h = hsv.at<cv::Vec3b>(0, 0)[0];
    auto s = hsv.at<cv::Vec3b>(0, 0)[1];
    auto v = hsv.at<cv::Vec3b>(0, 0)[2];

    bool rgb_check = pixel[2] >= 70 && pixel[2] <= 255 &&
                     pixel[1] >= 0 && pixel[1] <= 190 &&
                     pixel[0] >= 120 && pixel[0] <= 255;

    bool hsv_check = h >= 270 && h <= 310 &&
                     s >= 38 && s <= 100 &&
                     v >= 40 && v <= 100;

    return rgb_check && hsv_check;
}

cv::Point FindTarget(const cv::Mat& screen, float fov_x, float fov_y) {
    int center_x = screen.cols / 2;
    int center_y = screen.rows / 2;
    cv::Point target(-1, -1);
    float min_dist = FLT_MAX;

    for (int y = center_y - fov_y; y < center_y + fov_y; ++y) {
        for (int x = center_x - fov_x; x < center_x + fov_x; ++x) {
            if (x >= 0 && x < screen.cols && y >= 0 && y < screen.rows) {
                if (IsPurplePixel(screen.at<cv::Vec3b>(y, x))) {
                    float dist = sqrt(pow(x - center_x, 2) + pow(y - center_y, 2));
                    if (dist < min_dist) {
                        min_dist = dist;
                        target = cv::Point(x, y);
                    }
                }
            }
        }
    }
    return target;
}

// Chụp màn hình
cv::Mat CaptureScreen() {
    HDC hScreenDC = GetDC(NULL);
    int width = GetSystemMetrics(SM_CXSCREEN);
    int height = GetSystemMetrics(SM_CYSCREEN);
    HDC hMemoryDC = CreateCompatibleDC(hScreenDC);
    HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, width, height);
    SelectObject(hMemoryDC, hBitmap);
    BitBlt(hMemoryDC, 0, 0, width, height, hScreenDC, 0, 0, SRCCOPY);
    
    BITMAPINFOHEADER bi = { sizeof(bi), width, -height, 1, 24, BI_RGB };
    cv::Mat mat(height, width, CV_8UC3);
    GetDIBits(hMemoryDC, hBitmap, 0, height, mat.data, (BITMAPINFO*)&bi, DIB_RGB_COLORS);
    
    DeleteObject(hBitmap);
    DeleteDC(hMemoryDC);
    ReleaseDC(NULL, hScreenDC);
    return mat;
}

// Di chuyển chuột qua driver
bool MoveMouse(float target_x, float target_y, int smoothness, int speed) {
    int screen_width = GetSystemMetrics(SM_CXSCREEN);
    int screen_height = GetSystemMetrics(SM_CYSCREEN);
    float center_x = screen_width / 2.0f;
    float center_y = screen_height / 2.0f;

    float smooth_factor = 1.0f / (smoothness * 0.5f);
    float dx = (target_x - center_x) * smooth_factor;
    float dy = (target_y - center_y) * smooth_factor;

    HANDLE hDevice = CreateFile(L"\\\\.\\InputService", GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hDevice == INVALID_HANDLE_VALUE) {
        return false;
    }

    MOUSE_MOVE move = { (LONG)(dx * speed), (LONG)(dy * speed) };
    MOUSE_MOVE encrypted;
    encrypted.dx = move.dx ^ 0xDEADBEEF;
    encrypted.dy = move.dy ^ 0xDEADBEEF;

    DWORD bytesReturned;
    BOOL success = DeviceIoControl(hDevice, IOCTL_MOVE_MOUSE, &encrypted, sizeof(encrypted), NULL, 0, &bytesReturned, NULL);
    CloseHandle(hDevice);
    return success;
}

// Luồng aimbot
void AimbotThread() {
    static bool always_aim_active = false;
    while (true) {
        if (GetAsyncKeyState(aimbot.always_aim_key) & 0x8000) {
            always_aim_active = !always_aim_active;
            Sleep(200);
        }

        if (aimbot.enabled && (always_aim_active || GetAsyncKeyState(aimbot.key) & 0x8000)) {
            cv::Mat screen = CaptureScreen();
            cv::Point target = FindTarget(screen, aimbot.fov, aimbot.fov);
            if (target.x != -1) {
                target.x += offsets.head_offset_x;
                target.y += offsets.head_offset_y;
                MoveMouse(target.x, target.y, aimbot.smoothness, aimbot.speed);
            }
            Sleep(aimbot.delay);
        }
        Sleep(1);
    }
}

// Luồng aim assist
void AssistThread() {
    while (true) {
        if (assist.enabled && GetAsyncKeyState(assist.key) & 0x8000) {
            cv::Mat screen = CaptureScreen();
            cv::Point target = FindTarget(screen, assist.fov, assist.fov);
            if (target.x != -1) {
                MoveMouse(target.x, target.y, assist.smoothness, assist.speed);
            }
            Sleep(assist.delay);
        }
        Sleep(1);
    }
}

// Luồng triggerbot
void TriggerbotThread() {
    static bool trigger_active = false;
    while (true) {
        if (triggerbot.enabled && GetAsyncKeyState(triggerbot.key) & 0x8000) {
            trigger_active = !trigger_active;
            Sleep(200);
        }
        if (trigger_active) {
            cv::Mat screen = CaptureScreen();
            cv::Point target = FindTarget(screen, triggerbot.fov_x, triggerbot.fov_y);
            if (target.x != -1) {
                mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
                Sleep(triggerbot.sleep);
                mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
            }
            Sleep(triggerbot.delay);
        }
        Sleep(1);
    }
}

// DirectX 11 setup
void CreateRenderTarget() {
    ID3D11Texture2D* pBackBuffer;
    g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
    g_pd3dDevice->CreateRenderTargetView(pBackBuffer, nullptr, &g_mainRenderTargetView);
    pBackBuffer->Release();
}

bool CreateDeviceD3D(HWND hWnd) {
    DXGI_SWAP_CHAIN_DESC sd = { 0 };
    sd.BufferCount = 2;
    sd.BufferDesc.Width = 0;
    sd.BufferDesc.Height = 0;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd;
    sd.SampleDesc.Count = 1;
    sd.SampleDesc.Quality = 0;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    D3D_FEATURE_LEVEL featureLevel = D3D_FEATURE_LEVEL_11_0;
    if (D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, &featureLevel, 1, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, nullptr, &g_pd3dDeviceContext) != S_OK)
        return false;

    CreateRenderTarget();
    return true;
}

void CleanupDeviceD3D() {
    if (g_mainRenderTargetView) { g_mainRenderTargetView->Release(); g_mainRenderTargetView = nullptr; }
    if (g_pSwapChain) { g_pSwapChain->Release(); g_pSwapChain = nullptr; }
    if (g_pd3dDeviceContext) { g_pd3dDeviceContext->Release(); g_pd3dDeviceContext = nullptr; }
    if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = nullptr; }
}

// Giao diện ImGui
void RenderMenu() {
    ImGui::Begin("Aimbot Valorant");

    ImGui::Checkbox("Bật Aimbot", &aimbot.enabled);
    ImGui::SliderFloat("FOV Aimbot", &aimbot.fov, 10.0f, 200.0f);
    ImGui::SliderInt("Độ mượt", &aimbot.smoothness, 1, 15);
    ImGui::SliderInt("Tốc độ", &aimbot.speed, 1, 15);
    ImGui::SliderInt("Độ trễ (ms)", &aimbot.delay, 1, 15);

    if (selecting_aimbot_key) {
        ImGui::Text("Nhấn phím bất kỳ...");
        int key = GetPressedKey();
        if (key != -1) {
            aimbot.key = key;
            selecting_aimbot_key = false;
        }
    } else {
        if (ImGui::Button(("Phím Aimbot: " + GetKeyName(aimbot.key)).c_str())) {
            selecting_aimbot_key = true;
        }
    }

    ImGui::Checkbox("Luôn bật Aimbot", &aimbot.always_aim);
    if (selecting_always_aim_key) {
        ImGui::Text("Nhấn phím bất kỳ...");
        int key = GetPressedKey();
        if (key != -1) {
            aimbot.always_aim_key = key;
            selecting_always_aim_key = false;
        }
    } else {
        if (ImGui::Button(("Phím Always Aimbot: " + GetKeyName(aimbot.always_aim_key)).c_str())) {
            selecting_always_aim_key = true;
        }
    }

    ImGui::Checkbox("Bật Aim Assist", &assist.enabled);
    ImGui::SliderFloat("FOV Assist", &assist.fov, 10.0f, 100.0f); // Sửa lỗi: dùng assist.fov
    ImGui::SliderInt("Độ mượt Assist", &assist.smoothness, 1, 15);
    ImGui::SliderInt("Tốc độ Assist", &assist.speed, 1, 15);
    ImGui::SliderInt("Độ trễ Assist (ms)", &assist.delay, 1, 15);

    if (selecting_assist_key) {
        ImGui::Text("Nhấn phím bất kỳ...");
        int key = GetPressedKey();
        if (key != -1) {
            assist.key = key;
            selecting_assist_key = false;
        }
    } else {
        if (ImGui::Button(("Phím Assist: " + GetKeyName(assist.key)).c_str())) {
            selecting_assist_key = true;
        }
    }

    ImGui::SliderFloat("Offset Đầu X", &offsets.head_offset_x, -10.0f, 10.0f);
    ImGui::SliderFloat("Offset Đầu Y", &offsets.head_offset_y, -20.0f, 20.0f);

    ImGui::Checkbox("Bật Triggerbot", &triggerbot.enabled);
    ImGui::SliderFloat("FOV Triggerbot X", &triggerbot.fov_x, 1.0f, 20.0f);
    ImGui::SliderFloat("FOV Triggerbot Y", &triggerbot.fov_y, 1.0f, 20.0f);
    ImGui::SliderInt("Độ trễ Triggerbot (ms)", &triggerbot.delay, 1, 15);
    ImGui::SliderInt("Sleep Triggerbot (ms)", &triggerbot.sleep, 1, 15);

    if (selecting_triggerbot_key) {
        ImGui::Text("Nhấn phím bất kỳ...");
        int key = GetPressedKey();
        if (key != -1) {
            triggerbot.key = key;
            selecting_triggerbot_key = false;
        }
    } else {
        if (ImGui::Button(("Phím Triggerbot: " + GetKeyName(triggerbot.key)).c_str())) {
            selecting_triggerbot_key = true;
        }
    }

    ImGui::End();
}

// Main window
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;

    switch (msg) {
    case WM_SIZE:
        if (g_pd3dDevice != nullptr && wParam != SIZE_MINIMIZED) {
            CleanupDeviceD3D();
            CreateDeviceD3D(hWnd);
        }
        return 0;
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU)
            return 0;
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

int main() {
    WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, WndProc, 0L, 0L, GetModuleHandle(nullptr), nullptr, nullptr, nullptr, nullptr, L"Aimbot", nullptr };
    RegisterClassEx(&wc);
    HWND hwnd = CreateWindow(wc.lpszClassName, L"Aimbot Valorant", WS_OVERLAPPEDWINDOW, 100, 100, 1280, 800, nullptr, nullptr, wc.hInstance, nullptr);

    if (!CreateDeviceD3D(hwnd)) {
        CleanupDeviceD3D();
        UnregisterClass(wc.lpszClassName, wc.hInstance);
        return 1;
    }

    ShowWindow(hwnd, SW_SHOWDEFAULT);
    UpdateWindow(hwnd);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    ImGui::StyleColorsDark();
    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

    std::thread aimbot_thread(AimbotThread);
    std::thread assist_thread(AssistThread);
    std::thread triggerbot_thread(TriggerbotThread);
    aimbot_thread.detach();
    assist_thread.detach();
    triggerbot_thread.detach();

    MSG msg;
    ZeroMemory(&msg, sizeof(msg));
    while (msg.message != WM_QUIT) {
        if (PeekMessage(&msg, nullptr, 0U, 0U, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
            continue;
        }

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();
        RenderMenu();
        ImGui::EndFrame();

        g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, nullptr);
        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, (float[]){0.0f, 0.0f, 0.0f, 1.0f});
        ImGui::Render();
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        g_pSwapChain->Present(1, 0);
    }

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    CleanupDeviceD3D();
    DestroyWindow(hwnd);
    UnregisterClass(wc.lpszClassName, wc.hInstance);
    return 0;
}